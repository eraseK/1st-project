
public class mumu_main {

	public static void main(String[] args) {
		mumu1 mu = new mumu1();
		mumu2 mu2 = new mumu2();
		
		
		
		mu.maindisplay();// 회원가입, 로그인, 아이디찾기, 비번찾기
//		mu2.logindisplay(); // 로그인 후 검색, 회원정보 수정,삭제, 재생목록확인
//		mumu1 m = new mumu1();
//		System.out.println(m.id());
	}

}

