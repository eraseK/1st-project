public class Music {
	public static void main(String[] args) {
		
		mumu2 mu2 =  null;
		//mu2.logindisplay();
	}
}
